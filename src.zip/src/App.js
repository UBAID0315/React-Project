import { useState } from 'react';
import './App.css';
import Footer from './MyComponents/Footer';
import Navbar from './MyComponents/Navbar';
import ItemsList from './MyComponents/ItemsList';
import AddItem from './MyComponents/AddItem';

function App() {

  const additem=(title,desc)=>
  {
    console.log("I am on add function of item",title,desc)

    // Addition of new Item

    let sno = items[items.length-1].sno+1;

    const myItem =
      {
        sno:sno,
        title:title,
        desc:desc,
      }
    setItems([...items,myItem]);
    console.log(myItem)
  }

  const onDelete=(item)=>
  {
    console.log("I am a on delete function of item",item);

    setItems(items.filter((e)=>{
      return e!==item;
    }))
  }

  const [items,setItems]= useState([
    {
      sno:1,
      title:"go to market",
      desc: "in this task you just goto the market"
    },
    {
      sno:2,
      title:"buy some products",
      desc:"buy whatever you want from the market"
    },
    {
      sno:3,
      title:"go back home",
      desc:"after buying come back to home"
    }
  ])
  // let todos = [
  //   {
  //     sno:1,
  //     title:"go to market",
  //     desc: "in this task you just goto the market"
  //   },
  //   {
  //     sno:2,
  //     title:"buy some products",
  //     desc:"buy whatever you want from the market"
  //   },
  //   {
  //     sno:3,
  //     title:"go back home",
  //     desc:"after buying come back to home"
  //   }
  // ]
  return (
    <>
      <Navbar title="React App" SearchBar={true}/>
      <AddItem additem={additem}/>
      <ItemsList items={items} onDelete={onDelete}/>
      <Footer/>
    </>
  );
}

export default App;
