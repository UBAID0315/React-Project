import { useState } from "react"
import React from 'react'


export const AddItem = ({additem}) => {
    
    const [title,setTitle] = useState("");
    const [desc,setDesc] = useState("");

    const submit = (e) =>
    {
        e.preventDefault()
        if(!title || !desc)
        {
            alert("Title or desc input should not be blank!")
        }

        additem(title,desc);
    }
    return (
    <div>
      <h3 className='text-center mt-5'>Add Item</h3>
            <form action="/" onSubmit={submit} className='form'>
                <div className="mb-3 mt-3">
                    <label htmlFor="email" className="form-label">Title:</label>
                    <input type="text" value={title} onChange={(e)=>setTitle(e.target.value)} className="form-control" id="text" placeholder="Enter title" name="title"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="pwd" className="form-label">Description:</label>
                    <input type="text" value={desc} onChange={(e)=>setDesc(e.target.value)} className="form-control" id="text" placeholder="Enter desc" name="desc"/>
                </div>
                <button type="submit" className="btn btn-sm btn-success d-block mx-auto">Add</button>
            </form>
    </div>
  )
}

export default AddItem; 
