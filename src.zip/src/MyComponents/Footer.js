import React from 'react'

const Footer = () => {
  return (
    <div>
      <footer>Copyright &copy; 2024 with Ubaid</footer>
    </div>
  )
}

export default Footer
