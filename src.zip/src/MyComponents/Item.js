import React from 'react'

// const Item = (props) => {
//   return (
//     <div>
        // <h2>{item.sno})</h2>
        // <p>{item.title}</p>
        // <p>{item.desc}</p>
//     </div>
//   )
// }

const Item = ({item,onDelete}) => {
    return (
      <>
      <h2>{item.sno})</h2>
      <div className='text-center'>
        <p>{item.title}</p>
        <p>{item.desc}</p>
        <button className='btn btn-sm btn-danger' onClick={()=>{onDelete(item)}}>Delete</button>
        <hr/>
      </div>
      </>
    )
}

export default Item
