import React from 'react'
import Item from './Item'

const ItemsList = (props) => {
  return (
    <div className='container'>
      <h3 className='text-center'>Doing Work List</h3>
      <div className="item col-9">
        {props.items.length ===0?"No todos to show":
        props.items.map((item)=>{
            return <Item item={item} key={item.sno} onDelete={props.onDelete}/>
        })
      }
      </div>
    </div>
  )
}

export default ItemsList
